name = str(input('What is your name?\n'))
print('hello, '+ name)