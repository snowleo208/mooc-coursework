#include <stdio.h>

int main(void)
{
    printf("hey, world\n");
}
